import UIKit

func square(math: Int) -> Int {
    let number = math * math
    return (number)
}
print(square(math: 7))


func five() -> Int {
    return 5
}
print(five())


func fullName(first: String, last: String) -> String {
    return first + " " + last
}
print(fullName(first: "Dani", last: "Lubezki"))


func shout(input: String) -> String {
    return input + "!"
}
print(shout(input: "Hi"))


func numberName(num: Int) -> String! {
    let letters = ["Zero","One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"]
    if num <= 9 {
        return letters[num]
    }
    else {
        return nil
    }
}
print(numberName(num: 6))
